from django.core.paginator import Paginator
from django.shortcuts import render

from product.models import Product, Category


def home(request):
    products = Product.objects.all().order_by('-price')
    return render(
        request=request,
        template_name='index.html',
        context={
            'products':products
        }
    )

def products(request):
    cat = request.GET.get('cat',None)
    page:str = request.GET.get('page',1)
    if cat:
        product_list = Product.objects.filter(category_id=cat)
    else:
        product_list = Product.objects.all()
    category_list = Category.objects.all()
    paginator = Paginator(
        object_list=product_list,
        per_page=6
    )
    page = int(page)
    page = page if page<=paginator.num_pages else paginator.num_pages
    product_list_page = paginator.get_page(page)
    return render(
        request=request,
        template_name='product/products.html',
        context={
            'products':product_list_page,
            'categories':category_list,
            'title':'Mahsulotlar',
            'paginator':paginator,
            'current_page':int(page)
        }
    )

def product_detail(request,id):
    product = Product.objects.get(id=id)
    return render(
        request=request,
        template_name='product/product-detail.html',
        context={
            'product':product
        }
    )

def search(request):
    search_text = request.GET.get('search',None)
    product_list = Product.objects.filter(name__icontains=search_text)
    category_list = Category.objects.all()
    return render(
        request=request,
        template_name='product/products.html',
        context={
            'products':product_list,
            'categories':category_list,
            'title':'Mahsulotlar'
        }
    )